# ShareSerial v1.0.0 - Linux

## 文件列表

| 文件 | 用途 |
|------|------|
| shareserial-server | 服务端（物理串口共享） |
| shareserial-client | 客户端（虚拟串口） |
| shareserial | CLI 工具（AI 接口） |

## 快速开始

### 服务端
```bash
# 扫描可用串口
./shareserial-server --scan

# 启动服务（共享 /dev/ttyUSB0）
./shareserial-server --serial /dev/ttyUSB0 --port 7700
```

### 客户端
```bash
# 连接服务器，创建虚拟串口
./shareserial-client --server 192.168.1.100:7700 --pty /dev/ttyShare

# 使用虚拟串口（任何串口工具）
cat /dev/ttyShare
```

### CLI 工具（AI 接口）
```bash
# 获取日志（JSON 输出）
./shareserial log --server 192.168.1.100:7700 --json

# 查看状态
./shareserial status --server 192.168.1.100:7700

# 发送命令（自动管理写锁）
./shareserial send --command "ls" --server 192.168.1.100:7700
```

## 权限要求

需要串口访问权限：
```bash
sudo usermod -a -G dialout $USER
```

## 系统要求

- Ubuntu 18.04+ 或兼容发行版
- Linux 内核 4.x+