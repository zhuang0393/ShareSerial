# ShareSerial v1.0.0 - macOS (Apple Silicon)

## 文件列表

| 文件 | 用途 |
|------|------|
| shareserial-server-darwin-arm64 | 服务端（物理串口共享） |
| shareserial-client-darwin-arm64 | 客户端（虚拟串口） |
| shareserial-darwin | CLI 工具（AI 接口） |

## 快速开始

### 服务端
```bash
# 扫描可用串口
./shareserial-server-darwin-arm64 --scan

# 启动服务（共享 /dev/tty.usbserial）
./shareserial-server-darwin-arm64 --serial /dev/tty.usbserial --port 7700
```

### 客户端
```bash
# 连接服务器，创建虚拟串口
./shareserial-client-darwin-arm64 --server 192.168.1.100:7700 --pty /dev/ttysShare
```

### CLI 工具
```bash
./shareserial-darwin log --server 192.168.1.100:7700
./shareserial-darwin status --server 192.168.1.100:7700
./shareserial-darwin send --command "ls" --server 192.168.1.100:7700
```

## 系统要求

- macOS 11.0+ (Apple Silicon Mac)