# ShareSerial v1.0.0 - Windows

## 文件列表

| 文件 | 用途 |
|------|------|
| shareserial-server-windows.exe | 服务端（物理串口共享） |
| shareserial-client-windows.exe | 客户端（虚拟串口代理） |
| shareserial-cli-windows.exe | CLI 工具（AI 接口） |

## 快速开始

### 服务端
```cmd
# 扫描可用 COM 口
shareserial-server-windows.exe --scan

# 启动服务（共享 COM1）
shareserial-server-windows.exe --serial COM1 --port 7700
```

### 客户端
```cmd
# 连接服务器，创建本地代理端口
shareserial-client-windows.exe --server 192.168.1.100:7700 --local-port 8888

# 使用 Putty 连接本地代理
# Connection type: Raw
# Host: localhost
# Port: 8888
```

### CLI 工具（AI 接口）
```cmd
# 获取日志
shareserial-cli-windows.exe log --server 192.168.1.100:7700

# 查看状态
shareserial-cli-windows.exe status --server 192.168.1.100:7700

# 发送命令
shareserial-cli-windows.exe send --command "ls" --server 192.168.1.100:7700
```

## 系统要求

- Windows 10/11
- 无需额外依赖（单文件绿色版）

## 注意事项

- Windows 客户端使用本地 TCP 代理模式（不是虚拟串口驱动）
- Phase 2 将支持真正的虚拟串口驱动（COM 口）